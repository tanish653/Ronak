import React, { useState, useEffect } from "react";
import TaskInput from "./components/TaskInput";
import TaskItem from "./components/TaskItem";
import Stats from "./components/Stats";

const getLocalItems = () => {
  let list = localStorage.getItem("list");
  if (list) {
    return JSON.parse(list);
  } else {
    return [];
  }
};

const App = () => {
  const [toDoList, setToDoList] = useState(getLocalItems());

  const addTask = (taskName) => {
    const newTask = { taskName, checked: false };
    setToDoList([...toDoList, newTask]);
  };

  const deleteTask = (deleteTaskName) => {
    setToDoList(toDoList.filter((task) => task.taskName !== deleteTaskName));
  };

  const toggleCheck = (taskName) => {
    setToDoList((prevToDoList) =>
      prevToDoList.map((task) =>
        task.taskName === taskName ? { ...task, checked: !task.checked } : task
      )
    );
  };

  useEffect(() => {
    localStorage.setItem("list", JSON.stringify(toDoList));
  }, [toDoList]);

  return (
    <>
      <div className="container">
        <h1>Task Management</h1>

        <TaskInput addTask={addTask} />

        <div className="toDoList">
          <span>Your Motivation</span>
          <ul className="list-items">
            {toDoList.map((task, index) => (
              <TaskItem
                task={task}
                key={index} // Use index or task.taskName if unique
                deleteTask={deleteTask}
                toggleCheck={toggleCheck}
              />
            ))}
          </ul>

          {toDoList.length === 0 ? (
            <p className="notify">You Are There Keep Hardworking..</p>
          ) : null}
        </div>
      </div>
      <Stats toDoList={toDoList} />
    </>
  );
};

export default App;
