import React from "react";

const Stats = ({ toDoList }) => {
  let countList = toDoList.length;
  return (
    <div className="stats">
      <p className="notify">
        {countList === 0
          ? "You Got EveryThing and You can do it.."
          : `You Have ${countList} items on your list.`}
      </p>
    </div>
  );
};

export default Stats;
